using System.Reflection;
using System.Runtime.CompilerServices;

//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly: AssemblyTitle("SourceGrid2")]
[assembly: AssemblyDescription("Open Source C# Grid Control")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Davide Icardi http://www.devage.com/")]
[assembly: AssemblyProduct("SourceGrid2")]
[assembly: AssemblyCopyright("Davide Icardi")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		

[assembly: AssemblyVersion("2.0.3.0")]
[assembly: AssemblyInformationalVersion("2.0.3.0")]
[assembly: AssemblyFileVersion("2.0.3.0")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("..\\..\\SourceGrid2.snk")]
[assembly: AssemblyKeyName("")]
